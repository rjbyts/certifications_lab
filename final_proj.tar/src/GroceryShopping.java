import java.util.Scanner;
// Custom exception class for item not found
class ItemNotFoundException extends Exception {
    public ItemNotFoundException(String message) {
        super(message);
    }
}
public class GroceryShopping{
    public static void main (String s[]){
        String items[] = {"milk", "egg", "cheese", "pasta", "meat", "onion", "bread", "juice", "candy", "water"};
        float price[] = {0.50f, 0.30f, 2.00f, 3.00f, 4.00f, 0.10f, 0.40f, 1.00f, 0.05f, 1.50f};
        Scanner scanner = new Scanner(System.in);

        while(true){
            float totalBill = 0.0f;
            while(true){
                try {
                System.out.println("Enter the name of the item (or type 'finish' to end shopping):");
                String inputItem = scanner.nextLine();
                //String cart[] = new String[];
                if (inputItem.equalsIgnoreCase("finish")) {
                    System.out.println("Your total bill is: $" + totalBill);
                    System.out.println("Thank you for shopping with us!");
                    break;
                }
                int itemsIndex = -1;
                for (int i = 0; i < items.length; i++) {
                    if (items[i].equalsIgnoreCase(inputItem)) {
                        itemsIndex = i;
                        break;
                    }
                }
                if (itemsIndex == -1) {
                    throw new ItemNotFoundException("Item '" + inputItem + "' not found. Please try again.");
                }
                System.out.println("Enter the quantity of " + items[itemsIndex] + ":");
                    int quantity = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character
                    // Calculate the cost for the item and add it to the total bill
                    float itemCost = price[itemsIndex] * quantity;
                    totalBill += itemCost;
                    System.out.println("Added " + quantity + " x " + items[itemsIndex] + " to the bill. Current total: $" + totalBill);
            } catch (ItemNotFoundException e) {
                System.out.println(e.getMessage()); // Print the exception message
            } catch (Exception e) {
                System.out.println("Invalid input. Please try again.");
                scanner.nextLine(); // Clear the invalid input
            }
        }
        String userInput = scanner.nextLine();
            if (userInput.equalsIgnoreCase("exit")) {
                System.out.println("Thank you for using the shopping cart. Goodbye!");
                break;
            } 
        }
        scanner.close();
    }
}